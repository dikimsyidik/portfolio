# Clones the foundation-docs repo and links it to NPM locally
git clone https://github.com/zurb/foundation-docs
npm link ./foundation-docs
